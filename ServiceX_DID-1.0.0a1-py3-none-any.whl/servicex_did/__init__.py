__version__ = '1.0.0a1'

from .communication import start_did_finder  # NOQA
